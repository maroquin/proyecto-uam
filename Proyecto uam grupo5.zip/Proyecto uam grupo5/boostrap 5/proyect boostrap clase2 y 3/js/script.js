console.log("hello world");

var n1=120;
var n2=195;
var r=n1+n2;
console.log("resultado de la suma es : "+ r);

var n3=120;
var n4=2;
var rml=n3*n4;
console.log("resultado de multiplicacion es : "+ rml);

var n5=1244;
var rsq=Math.sqrt(n5);
console.log("la raiz de 1244 es : "+ rsq);
var intsq=Math.floor(rsq);
console.log("la raiz de 1244 en entero es : "+ intsq);